/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionrestaurante;

/**
 *
 * @author maxim
 */
public class Postre extends Plato implements Decorable{
    private boolean contieneAzucar;

    public Postre(String nombre, double precio, TipoDePreparacion tipo, boolean contieneAzucar) {
        super(nombre, precio, tipo);
        this.contieneAzucar = contieneAzucar;
    }

    public boolean isContieneAzucar() {
        return contieneAzucar;
    }
    
    @Override
    public String detallesEspecificos(){
        return ("Contiene azucar= "+contieneAzucar);
    }
    
    @Override
    public void decorar() {
        System.out.println("Decorando entrada"+ getNombre());
    }
}
