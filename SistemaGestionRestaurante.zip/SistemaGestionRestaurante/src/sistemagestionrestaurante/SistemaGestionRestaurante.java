
package sistemagestionrestaurante;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author maxim
 */
public class SistemaGestionRestaurante {

    public static void main(String[] args) {

        Restaurante restaurante = new Restaurante();
        try {
            
            Plato bruschetta = new Entrada("bruschetta", 15000, TipoDePreparacion.FRIO, 5);
            Plato bruschetta2 = new Entrada("bruschetta", 15000, TipoDePreparacion.FRIO, 5);
            Plato salmon = new PlatoPrincipal("salmon", 45000, TipoDePreparacion.FRIO, 30);
            Plato empanada = new Entrada("empanada", 2500, TipoDePreparacion.CALIENTE, 3);
            Plato milanesa = new PlatoPrincipal("milanesa", 25000, TipoDePreparacion.CALIENTE, 20);
            Plato helado = new Postre("helado", 4000, TipoDePreparacion.FRIO, true);
            
            restaurante.agregarPlato(bruschetta);
            restaurante.agregarPlato(salmon);
            restaurante.agregarPlato(empanada);
            restaurante.agregarPlato(milanesa);
            restaurante.agregarPlato(helado);
            
            System.out.println("PRUEBA PLATO REPETIDO:");
            restaurante.agregarPlato(bruschetta2);
        
        } catch (PlatoDuplicadoExeption ex) {
            System.out.println(ex.getMessage());
        }
        
        System.out.println("\nSE MUESTRAN LOS PLATOS");
        restaurante.mostrarPlatos();
        
        System.out.println("\nSE PREPARAN LOS PLATOS");
        restaurante.prepararPlato();
        
        System.out.println("\nSE DECORAN LOS PLATOS");
        restaurante.decorarPlato();
        
        System.out.println("\nFILTRADO POR TIPO DE PREPARACION\n");
        restaurante.filtrarPorTipoPreparacion(TipoDePreparacion.FRIO);
        System.out.println("\n");
        restaurante.filtrarPorTipoPreparacion(TipoDePreparacion.CALIENTE);
        
        // FILTRADO
        System.out.println("\nFILTRADO POR TIPO DE PLATO:\n");
        restaurante.filtrarPlatoPorTipo("Entrada");
        System.out.println("\n");
        restaurante.filtrarPlatoPorTipo("PlatoPrincipal");
        System.out.println("\n");
        restaurante.filtrarPlatoPorTipo("Postre");
    }
}
