package sistemagestionrestaurante;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author maxim
 */
public class Restaurante {

    private List<Plato> platos = new ArrayList<>();

    //metodos
    public void agregarPlato(Plato plato) throws PlatoDuplicadoExeption {
        validarPlato(plato);
        platos.add(plato);
    }

    public void validarPlato(Plato plato) throws PlatoDuplicadoExeption {
        if (plato == null) {
            System.out.println("Plato nulo");
        }
        for (Plato p : platos) {
            if (p.getNombre().equalsIgnoreCase(plato.getNombre()) && p.getTipo().equals(plato.getTipo())) {
                throw new PlatoDuplicadoExeption("Plato " + p.getNombre() + " de tipo " + p.getTipo() + " ya existe.");
            }
        }
    }

    public void mostrarPlatos() {
        if (platos.isEmpty()) {
            System.out.println("Lista de platos vacia");
        } else {
            for (Plato p : platos) {
                System.out.println(p.toString());
            }
        }
    }

    public void prepararPlato() {
        for (Plato p : platos) {
            if (p instanceof Preparable prep) {
                prep.preparar();
                System.out.println(p.tipoPlato()+ " " + p.getNombre() + " esta siendo preparado.");
            } else {
                System.out.println(p.getNombre() + " no puede ser preparado.");
            }
        }
    }

    public void decorarPlato() {
        for (Plato p : platos) {
            if (p instanceof Decorable deco) {
                deco.decorar();
                System.out.println(p.tipoPlato()+ " " +p.getNombre() + " esta siendo decorado.");
            } else {
                System.out.println(p.getNombre() + " no puede ser decorado.");
            }
        }
    }

    public void filtrarPorTipoPreparacion(TipoDePreparacion tipo) {
        System.out.println("Platos de tipo: " + tipo);
        for (Plato p : platos) {
            if (p.getTipo().equals(tipo)) {
                System.out.println(p.toString());
            }
        }
    }

    public void filtrarPlatoPorTipo(String tipoPlato) {
        System.out.println("Platos de tipo: " + tipoPlato);
        for (Plato p : platos) {
            if (p.getClass().getSimpleName().equals(tipoPlato)) {
                System.out.println(p.toString());
            }
        }
    }

}
