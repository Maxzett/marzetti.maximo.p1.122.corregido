/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionrestaurante;

/**
 *
 * @author maxim
 */
public class PlatoPrincipal extends Plato implements Preparable{
    private int tiempoParaCoccion;

    public PlatoPrincipal(String nombre, double precio, TipoDePreparacion tipo, int tiempoParaCoccion) {
        super(nombre, precio, tipo);
        this.tiempoParaCoccion = tiempoParaCoccion;
    }
    
    @Override
    public String detallesEspecificos(){
        return ("Tiempo de coccion= "+tiempoParaCoccion +" minutos");
    }
    
    @Override
    public void preparar() {
        System.out.println("Preparando Plato principal: "+ getNombre());
    }
}
