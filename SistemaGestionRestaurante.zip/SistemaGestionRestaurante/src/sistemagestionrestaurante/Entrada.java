/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionrestaurante;

/**
 *
 * @author maxim
 */
public class Entrada extends Plato implements Preparable, Decorable{
    private double cantIngredientes;

    public Entrada(String nombre, double precio, TipoDePreparacion tipo, double cantIngredientes) {
        super(nombre, precio, tipo);
        this.cantIngredientes = cantIngredientes;
    }
    
    @Override
    public String detallesEspecificos(){
        return (" Cantidad Ingredientes= "+cantIngredientes);
    }
    
    @Override
    public void preparar() {
        System.out.println("Preparando entrada "+ getNombre());
    }
    
    @Override
    public void decorar() {
        System.out.println("Decorando entrada "+ getNombre());
    }
}
