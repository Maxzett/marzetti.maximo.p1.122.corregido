/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionrestaurante;

import java.util.Objects;

/**
 *
 * @author maxim
 */
public abstract class Plato {
    private String nombre;
    private double precio;
    private TipoDePreparacion tipo;
    
    //Constructor
    public Plato(String nombre, double precio, TipoDePreparacion tipo) {
        this.nombre = nombre;
        this.precio = precio;
        this.tipo = tipo;
    }
    
    //getters
    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public TipoDePreparacion getTipo() {
        return tipo;
    }
    
    public String tipoPlato() {
        return this.getClass().getSimpleName();
    }
    
    //metodos
    
    protected abstract String detallesEspecificos();

    @Override
    public String toString() {
        return String.format("[%s] Nombre: %s | Precio: $%.2f | Preparacion: %s | %s",
                tipoPlato(), nombre, precio, tipo, detallesEspecificos());
    }
}
