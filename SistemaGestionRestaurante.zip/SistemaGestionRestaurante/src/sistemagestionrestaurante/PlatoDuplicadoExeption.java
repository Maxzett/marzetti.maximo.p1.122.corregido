/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package sistemagestionrestaurante;

/**
 *
 * @author maxim
 */
public class PlatoDuplicadoExeption extends Exception {
    
    private static final String MESSAGE = "ERROR: este plato ya existe.";
    
    public PlatoDuplicadoExeption() {
        this(MESSAGE);
    }
    
    public PlatoDuplicadoExeption(String msg) {
        super(msg);
    }
}
